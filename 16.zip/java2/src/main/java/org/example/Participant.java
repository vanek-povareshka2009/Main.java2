package org.example;

public interface Participant {
    boolean jump(int height);
    boolean run(int dist);
}
