package org.example;

public interface Challenge {
    boolean contest(Participant participant);
}
